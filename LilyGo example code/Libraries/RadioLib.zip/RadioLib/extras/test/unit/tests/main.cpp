#define BOOST_TEST_MODULE "RadioLib Unit test"
#include <boost/test/included/unit_test.hpp>

// intentionally left blank, boost.test creates its own entrypoint

